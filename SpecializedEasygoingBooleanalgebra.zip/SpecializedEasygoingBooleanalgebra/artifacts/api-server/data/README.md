# Sunflare Studios disk storage

This folder is the file-backed storage layer for the first build. Public submissions
are stored in `submissions/`, while the dashboard keeps `tasks.json` and `team.json`
here. Set `SUNFLARE_DATA_DIR` to point at a different persistent disk location when
deploying. Keep credentials and webhook URLs in workspace secrets, never in these files.