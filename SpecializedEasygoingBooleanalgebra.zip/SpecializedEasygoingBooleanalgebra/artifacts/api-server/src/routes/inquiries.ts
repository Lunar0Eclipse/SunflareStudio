import { randomUUID } from "node:crypto";
import { Router, type IRouter } from "express";
import {
  CreateCommissionInquiryBody,
  CreateCommissionInquiryResponse,
  CreateRecruitmentApplicationBody,
  CreateRecruitmentApplicationResponse,
} from "@workspace/api-zod";
import { sendDiscordWebhook } from "../lib/discord";
import { writeSubmission } from "../lib/storage";
import { createAssistantResponse } from "../lib/ai";

const router: IRouter = Router();

router.post("/inquiries/assistant", async (req, res) => {
  const { kind, step, answer, answers } = req.body ?? {};
  if (
    typeof kind !== "string" ||
    typeof step !== "string" ||
    typeof answer !== "string" ||
    !answers ||
    typeof answers !== "object"
  ) {
    res.status(400).json({ error: "A guided inquiry step is required." });
    return;
  }
  try {
    res.json(await createAssistantResponse({ kind, step, answer, answers }));
  } catch (error) {
    req.log.error({ err: error }, "Inquiry assistant failed");
    res.status(503).json({ error: "The assistant is taking a beat. Please try this step again." });
  }
});

router.post("/inquiries/commission", async (req, res) => {
  const parsed = CreateCommissionInquiryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please complete all required fields." });
    return;
  }
  const id = randomUUID();
  const payload = { id, type: "commission", createdAt: new Date().toISOString(), ...parsed.data };
  await writeSubmission("commission", id, payload);
  try {
    await sendDiscordWebhook("New commission inquiry", payload);
  } catch (error) {
    req.log.error({ err: error, submissionId: id }, "Commission webhook failed");
    res.status(502).json({ error: "We saved your inquiry but could not notify Discord." });
    return;
  }
  res.status(201).json(
    CreateCommissionInquiryResponse.parse({
      id,
      message: `Your brief is in. Order ${id.slice(0, 8).toUpperCase()} is ready for Discord.`,
    }),
  );
});

router.post("/inquiries/recruitment", async (req, res) => {
  const parsed = CreateRecruitmentApplicationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please complete all required fields." });
    return;
  }
  const id = randomUUID();
  const payload = { id, type: "recruitment", createdAt: new Date().toISOString(), ...parsed.data };
  await writeSubmission("recruitment", id, payload);
  try {
    await sendDiscordWebhook("New recruitment application", payload);
  } catch (error) {
    req.log.error({ err: error, submissionId: id }, "Recruitment webhook failed");
    res.status(502).json({ error: "We saved your application but could not notify Discord." });
    return;
  }
  res.status(201).json(
    CreateRecruitmentApplicationResponse.parse({
      id,
      message: "Application received. We will review your work and reach out.",
    }),
  );
});

export default router;