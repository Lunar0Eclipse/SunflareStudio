import { randomUUID } from "node:crypto";
import { Router, type IRouter } from "express";
import {
  CreateDashboardTaskBody,
  CreateDashboardTaskResponse,
  GetDashboardSummaryResponse,
  GetDashboardTasksResponse,
  GetTeamRosterResponse,
  UpdateDashboardTaskBody,
  UpdateDashboardTaskParams,
  UpdateDashboardTaskResponse,
} from "@workspace/api-zod";
import { sendDiscordWebhook } from "../lib/discord";
import { getSession } from "../lib/session";
import { readJson, writeJson } from "../lib/storage";
import { readMembers, seedMembers, writeMembers, type StudioMember } from "../lib/members";

type Task = {
  id: string;
  title: string;
  project: string;
  assignee: string;
  status: string;
  priority: string;
  details: string;
  updatedAt: string;
};

const seedTasks: Task[] = [
  {
    id: "task-combat",
    title: "Polish hit reaction pass",
    project: "Emberline",
    assignee: "Mira",
    status: "in_progress",
    priority: "High",
    details: "Tighten impact timing and add a readable finish-state cue.",
    updatedAt: new Date().toISOString(),
  },
  {
    id: "task-streaming",
    title: "Optimize city streaming cells",
    project: "Hollowpoint",
    assignee: "Ash",
    status: "in_progress",
    priority: "Medium",
    details: "Profile memory across the downtown blockout and trim duplicate props.",
    updatedAt: new Date().toISOString(),
  },
  {
    id: "task-hud",
    title: "Party HUD accessibility sweep",
    project: "Skybound Protocol",
    assignee: "Kairo",
    status: "todo",
    priority: "Low",
    details: "Check controller navigation, contrast, and screen-reader labels.",
    updatedAt: new Date().toISOString(),
  },
];

function requireTeam(req: Parameters<IRouter["get"]>[1] extends never ? never : any, res: any) {
  const session = getSession(req);
  if (!session) {
    res.status(401).json({ error: "Team authentication required." });
    return null;
  }
  return session;
}

function requireAdmin(req: Parameters<IRouter["get"]>[1] extends never ? never : any, res: any) {
  const session = requireTeam(req, res);
  if (!session) return null;
  if (!session.isAdmin) {
    res.status(403).json({ error: "Admin access required." });
    return null;
  }
  return session;
}

const router: IRouter = Router();

router.get("/dashboard/summary", async (req, res) => {
  if (!requireTeam(req, res)) return;
  const tasks = await readJson<Task[]>("tasks.json", seedTasks);
  const members = await readMembers();
  const summary = {
    activeProjects: 4,
    completedThisMonth: 12,
    openTasks: tasks.filter((task) => task.status !== "Done").length,
    teamMembers: members.length,
    activity: tasks.slice(0, 3).map((task) => ({
      id: task.id,
      type: task.status,
      message: `${task.assignee} moved ${task.title} to ${task.status}.`,
      timestamp: task.updatedAt,
    })),
  };
  res.json(GetDashboardSummaryResponse.parse(summary));
});

router.get("/dashboard/tasks", async (req, res) => {
  if (!requireTeam(req, res)) return;
  res.json(GetDashboardTasksResponse.parse(await readJson<Task[]>("tasks.json", seedTasks)));
});

router.post("/dashboard/tasks", async (req, res) => {
  const session = requireTeam(req, res);
  if (!session) return;
  const parsed = CreateDashboardTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please complete all task fields." });
    return;
  }
  const tasks = await readJson<Task[]>("tasks.json", seedTasks);
  const task = { id: randomUUID(), updatedAt: new Date().toISOString(), ...parsed.data };
  await writeJson("tasks.json", [...tasks, task]);
  await sendDiscordWebhook("Task created", { actor: session.username, task });
  res.status(201).json(CreateDashboardTaskResponse.parse(task));
});

router.patch("/dashboard/tasks/:id", async (req, res) => {
  const session = requireTeam(req, res);
  if (!session) return;
  const params = UpdateDashboardTaskParams.safeParse(req.params);
  const parsed = UpdateDashboardTaskBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: "Invalid task update." });
    return;
  }
  const tasks = await readJson<Task[]>("tasks.json", seedTasks);
  const index = tasks.findIndex((task) => task.id === params.data.id);
  if (index < 0) {
    res.status(404).json({ error: "Task not found." });
    return;
  }
  const before = tasks[index];
  const updated = { ...before, ...parsed.data, updatedAt: new Date().toISOString() };
  tasks[index] = updated;
  await writeJson("tasks.json", tasks);
  await sendDiscordWebhook("Task status changed", {
    actor: session.username,
    before,
    after: updated,
  });
  res.json(UpdateDashboardTaskResponse.parse(updated));
});

router.get("/dashboard/team", async (req, res) => {
  if (!requireTeam(req, res)) return;
  res.json(GetTeamRosterResponse.parse(await readMembers()));
});

router.get("/dashboard/members", async (req, res) => {
  if (!requireAdmin(req, res)) return;
  res.json(await readMembers());
});

router.put("/dashboard/members", async (req, res) => {
  const session = requireAdmin(req, res);
  if (!session) return;
  const members = req.body as StudioMember[];
  if (!Array.isArray(members) || members.some((member) => !member.id || !member.name || !member.role || !member.rank)) {
    res.status(400).json({ error: "Every member needs an id, name, role, and rank." });
    return;
  }
  await writeMembers(members);
  await sendDiscordWebhook("Roster updated", { actor: session.username, members });
  res.json(members);
});

export default router;