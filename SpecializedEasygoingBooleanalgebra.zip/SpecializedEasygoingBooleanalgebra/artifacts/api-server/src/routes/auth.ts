import { randomUUID } from "node:crypto";
import { Router, type IRouter } from "express";
import { GetSessionResponse } from "@workspace/api-zod";
import { clearSession, getSession, setSession } from "../lib/session";

const router: IRouter = Router();

function callbackUrl(req: Parameters<IRouter["get"]>[1] extends never ? never : any) {
  const forwardedProto = req.headers["x-forwarded-proto"];
  const forwardedHost = req.headers["x-forwarded-host"];
  const protocol = typeof forwardedProto === "string" ? forwardedProto.split(",")[0] : req.protocol;
  const host = typeof forwardedHost === "string" ? forwardedHost.split(",")[0] : req.get("host");
  return `${protocol}://${host}/api/auth/discord/callback`;
}

router.get("/auth/discord", (req, res) => {
  const clientId = process.env.DISCORD_CLIENT_ID;
  if (!clientId) {
    res.status(503).send("Discord OAuth is not configured.");
    return;
  }
  const state = randomUUID();
  res.setHeader(
    "set-cookie",
    `sunflare_oauth_state=${state}; HttpOnly; Path=/; SameSite=Lax; Max-Age=600`,
  );
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: callbackUrl(req),
    response_type: "code",
    scope: "identify",
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
});

router.get("/auth/discord/callback", async (req, res) => {
  const clientId = process.env.DISCORD_CLIENT_ID;
  const clientSecret = process.env.DISCORD_CLIENT_SECRET;
  const code = typeof req.query.code === "string" ? req.query.code : "";
  if (!clientId || !clientSecret || !code) {
    res.redirect("/team?auth=error");
    return;
  }
  const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      grant_type: "authorization_code",
      code,
      redirect_uri: callbackUrl(req),
    }),
  });
  if (!tokenResponse.ok) {
    res.redirect("/team?auth=error");
    return;
  }
  const token = (await tokenResponse.json()) as { access_token?: string };
  if (!token.access_token) {
    res.redirect("/team?auth=error");
    return;
  }
  const userResponse = await fetch("https://discord.com/api/users/@me", {
    headers: { authorization: `Bearer ${token.access_token}` },
  });
  if (!userResponse.ok) {
    res.redirect("/team?auth=error");
    return;
  }
  const user = (await userResponse.json()) as {
    id?: string;
    username?: string;
    avatar?: string | null;
  };
  const allowedIds = (process.env.DISCORD_TEAM_IDS ?? "")
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean);
  if (!user.id || !user.username || !allowedIds.includes(user.id)) {
    res.redirect("/team?auth=unauthorized");
    return;
  }
  setSession(res, {
    userId: user.id,
    username: user.username,
    avatar: user.avatar ?? undefined,
    isAdmin: (process.env.DISCORD_ADMIN_IDS ?? "")
      .split(",")
      .map((value) => value.trim())
      .filter(Boolean)
      .includes(user.id),
  });
  res.redirect("/team");
});

router.get("/auth/session", (req, res) => {
  const session = getSession(req);
  res.status(200).json(
    GetSessionResponse.parse(
      session
        ? {
            authenticated: true,
            userId: session.userId,
            username: session.username,
            avatar: session.avatar,
            isAdmin: session.isAdmin,
          }
        : { authenticated: false },
    ),
  );
});

router.post("/auth/logout", (req, res) => {
  clearSession(req, res);
  res.status(204).send();
});

export default router;