import { Router, type IRouter } from "express";
import {
  GetAssetsResponse,
  GetGamesResponse,
  GetPortfolioResponse,
  GetStudioOverviewResponse,
} from "@workspace/api-zod";
import { readMembers } from "../lib/members";

const router: IRouter = Router();

const overview = {
  name: "Sunflare Studios",
  tagline: "We build the worlds players remember.",
  description:
    "A Roblox game development team shipping bold systems, expressive worlds, and interfaces that make every interaction feel intentional.",
  discordUrl: "https://discord.gg/sunflare",
  activeProjects: 4,
  shippedGames: 7,
  disciplines: ["Game frameworks", "3D modeling", "VFX & lighting", "Custom UI"],
};

const assets = [
  {
    id: "combat-kit",
    title: "Vanguard Combat Kit",
    description:
      "A modular melee framework with hit-stop, combo windows, and authoritative server validation.",
    creator: "Kairo",
    creatorHandle: "kairo.dev",
    category: "Framework",
    image:
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1000&q=80",
    accent: "#f04a3b",
  },
  {
    id: "neon-vfx",
    title: "Neon Rift VFX Pack",
    description:
      "Impact bursts, trails, portals, and ability feedback built for fast, readable combat.",
    creator: "Mira",
    creatorHandle: "mira.fx",
    category: "VFX",
    image:
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1000&q=80",
    accent: "#ffb547",
  },
  {
    id: "modular-city",
    title: "Modular City Blockout",
    description:
      "A production-ready city kit with adaptable facades, props, and a clean streaming footprint.",
    creator: "Ash",
    creatorHandle: "ash.builds",
    category: "3D",
    image:
      "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1000&q=80",
    accent: "#6fe1c1",
  },
];

const games = [
  {
    id: "emberline",
    title: "Emberline",
    description:
      "A co-op extraction adventure through a city that keeps rebuilding itself.",
    genre: "Co-op adventure",
    image:
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1400&q=80",
    playUrl: "https://www.roblox.com/",
    status: "Live",
  },
  {
    id: "skybound",
    title: "Skybound Protocol",
    description:
      "Fast, vertical arena combat where every team owns the high ground.",
    genre: "Competitive action",
    image:
      "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1400&q=80",
    playUrl: "https://www.roblox.com/",
    status: "Live",
  },
  {
    id: "hollowpoint",
    title: "Hollowpoint",
    description:
      "A moody social mystery built around exploration, secrets, and strange signals.",
    genre: "Social mystery",
    image:
      "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1400&q=80",
    playUrl: "https://www.roblox.com/",
    status: "In development",
  },
];

const portfolio = [
  {
    id: "combat",
    title: "A combat framework that feels physical",
    summary:
      "We built a server-authoritative combat stack that keeps input responsive while preserving competitive integrity.",
    details: ["22ms average input-to-feedback", "Rollback-safe hit validation", "Data-driven combo authoring"],
    image:
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1400&q=80",
    tag: "SYSTEMS",
  },
  {
    id: "interface",
    title: "Interfaces with a pulse",
    summary:
      "From party HUDs to chat systems, we create readable interfaces that carry the tone of the world around them.",
    details: ["Controller-first navigation", "Motion language system", "Accessible color contrast"],
    image:
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1400&q=80",
    tag: "UI / UX",
  },
  {
    id: "worlds",
    title: "Worlds built for the camera",
    summary:
      "Our environments balance performance and composition, so the player always has somewhere interesting to look.",
    details: ["Streaming-aware modular kits", "Atmosphere and lighting passes", "Cinematic set dressing"],
    image:
      "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=1400&q=80",
    tag: "3D / WORLD",
  },
];

router.get("/studio/overview", (_req, res) => {
  res.json(GetStudioOverviewResponse.parse(overview));
});

router.get("/studio/assets", (_req, res) => {
  res.json(GetAssetsResponse.parse(assets));
});

router.get("/studio/games", (_req, res) => {
  res.json(GetGamesResponse.parse(games));
});

router.get("/studio/portfolio", (_req, res) => {
  res.json(GetPortfolioResponse.parse(portfolio));
});

router.get("/studio/members", async (_req, res) => {
  res.json(await readMembers());
});

export default router;