import { Router, type IRouter } from "express";
import healthRouter from "./health";
import studioRouter from "./studio";
import inquiriesRouter from "./inquiries";
import authRouter from "./auth";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(studioRouter);
router.use(inquiriesRouter);
router.use(authRouter);
router.use(dashboardRouter);

export default router;
