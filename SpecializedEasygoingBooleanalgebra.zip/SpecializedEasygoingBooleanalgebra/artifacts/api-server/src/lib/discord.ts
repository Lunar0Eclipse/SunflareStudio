import { logger } from "./logger";

export async function sendDiscordWebhook(
  event: string,
  payload: unknown,
): Promise<void> {
  const webhookUrl = process.env.DISCORD_WEBHOOK_URL;
  if (!webhookUrl) {
    throw new Error("DISCORD_WEBHOOK_URL is not configured");
  }

  const response = await fetch(webhookUrl, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      username: "Sunflare Ops",
      content: `Sunflare Studios · ${event}`,
      embeds: [
        {
          title: event,
          color: 0xe53b2f,
          description: "Structured event payload",
          fields: [
            {
              name: "JSON payload",
              value: `\`\`\`json\n${JSON.stringify(payload, null, 2).slice(0, 3900)}\n\`\`\``,
            },
          ],
          timestamp: new Date().toISOString(),
        },
      ],
    }),
  });

  if (!response.ok) {
    const body = await response.text();
    logger.error({ status: response.status, body }, "Discord webhook failed");
    throw new Error(`Discord webhook failed with ${response.status}`);
  }
}