import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

export const DATA_DIR = path.resolve(
  process.env.SUNFLARE_DATA_DIR ??
    path.join(process.cwd(), "artifacts", "api-server", "data"),
);

export async function ensureDataDir() {
  await mkdir(DATA_DIR, { recursive: true });
}

export async function readJson<T>(fileName: string, fallback: T): Promise<T> {
  await ensureDataDir();
  try {
    const raw = await readFile(path.join(DATA_DIR, fileName), "utf8");
    return JSON.parse(raw) as T;
  } catch {
    await writeJson(fileName, fallback);
    return fallback;
  }
}

export async function writeJson<T>(fileName: string, value: T) {
  await ensureDataDir();
  await writeFile(
    path.join(DATA_DIR, fileName),
    `${JSON.stringify(value, null, 2)}\n`,
    "utf8",
  );
}

export async function writeSubmission(
  type: "commission" | "recruitment",
  id: string,
  payload: unknown,
) {
  await ensureDataDir();
  const submissionsDir = path.join(DATA_DIR, "submissions");
  await mkdir(submissionsDir, { recursive: true });
  await writeFile(
    path.join(submissionsDir, `${type}-${id}.json`),
    `${JSON.stringify(payload, null, 2)}\n`,
    "utf8",
  );
}