type AssistantInput = {
  kind: string;
  step: string;
  answer: string;
  answers: Record<string, string>;
};

type AssistantOutput = {
  reply: string;
  nextQuestion: string;
  ready: boolean;
  summary: string;
};

const fallbackQuestions: Record<string, string> = {
  project: "Nice. What are you making, and what should players feel when they play it?",
  teamSize: "Got it. What kind of team is behind the build?",
  role: "Great. What do you make best, and what kind of work do you want to do with Sunflare?",
  portfolio: "Love that. Tell us a little about your experience or share a portfolio link.",
};

function localResponse(input: AssistantInput): AssistantOutput {
  const keys = Object.keys(input.answers);
  const ready = keys.length >= (input.kind === "commission" ? 3 : 3);
  const summary = Object.entries(input.answers)
    .map(([key, value]) => `${key}: ${value}`)
    .join(" · ");
  return {
    reply: input.answer.trim()
      ? "Locked in. That gives us a sharper read on the opportunity."
      : "No worries — we can keep it moving.",
    nextQuestion: ready ? "That is everything we need for the first pass." : fallbackQuestions[input.step] ?? "What should we know next?",
    ready,
    summary,
  };
}

export async function createAssistantResponse(input: AssistantInput): Promise<AssistantOutput> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return localResponse(input);

  const prompt = [
    "You are the warm, concise intake assistant for Sunflare Studios, a Roblox game development team.",
    "Respond with valid JSON only, with exactly: reply, nextQuestion, ready, summary.",
    "Keep reply to one or two friendly sentences. Ask one clear next question.",
    "Never ask for an email address. Do not promise pricing or delivery dates.",
    `Inquiry kind: ${input.kind}`,
    `Current step: ${input.step}`,
    `Current answer: ${input.answer}`,
    `All answers so far: ${JSON.stringify(input.answers)}`,
    "ready is true only when the answers are sufficient to create a useful inquiry.",
  ].join("\n");

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        response_format: { type: "json_object" },
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!response.ok) {
      await response.text();
      throw new Error(`OpenAI request failed with ${response.status}`);
    }
    const body = (await response.json()) as { choices?: Array<{ message?: { content?: string } }> };
    const content = body.choices?.[0]?.message?.content;
    if (!content) throw new Error("OpenAI returned an empty assistant response");
    const parsed = JSON.parse(content) as Partial<AssistantOutput>;
    if (
      typeof parsed.reply !== "string" ||
      typeof parsed.nextQuestion !== "string" ||
      typeof parsed.ready !== "boolean" ||
      typeof parsed.summary !== "string"
    ) {
      throw new Error("OpenAI returned an invalid assistant response");
    }
    return parsed as AssistantOutput;
  } catch {
    const fallback = localResponse(input);
    return {
      ...fallback,
      reply: "The live assistant is unavailable for this pass, so I’m keeping things moving with a fast local intake response.",
    };
  }
}