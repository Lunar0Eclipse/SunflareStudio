import { createHmac, randomBytes } from "node:crypto";
import type { Request, Response } from "express";

const COOKIE_NAME = "sunflare_session";
const SESSION_TTL_SECONDS = 60 * 60 * 24 * 7;

type Session = {
  userId: string;
  username: string;
  avatar?: string;
  isAdmin: boolean;
  expiresAt: number;
};

const sessions = new Map<string, Session>();

function secret() {
  return process.env.SESSION_SECRET ?? "sunflare-development-session-secret";
}

function sign(value: string) {
  return createHmac("sha256", secret()).update(value).digest("hex");
}

function parseCookies(req: Request) {
  const header = req.headers.cookie ?? "";
  return Object.fromEntries(
    header
      .split(";")
      .map((part) => part.trim().split("="))
      .filter(([key, value]) => key && value)
      .map(([key, ...value]) => [key, value.join("=")]),
  );
}

export function setSession(res: Response, session: Omit<Session, "expiresAt">) {
  const id = randomBytes(32).toString("hex");
  const expiresAt = Date.now() + SESSION_TTL_SECONDS * 1000;
  sessions.set(id, { ...session, expiresAt });
  const token = `${id}.${sign(id)}`;
  res.setHeader(
    "set-cookie",
    `${COOKIE_NAME}=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${SESSION_TTL_SECONDS}`,
  );
}

export function getSession(req: Request): Session | null {
  const token = parseCookies(req)[COOKIE_NAME];
  if (!token) return null;
  const [id, signature] = token.split(".");
  if (!id || !signature || signature !== sign(id)) return null;
  const session = sessions.get(id);
  if (!session || session.expiresAt < Date.now()) {
    sessions.delete(id);
    return null;
  }
  return session;
}

export function clearSession(req: Request, res: Response) {
  const token = parseCookies(req)[COOKIE_NAME];
  if (token) sessions.delete(token.split(".")[0]);
  res.setHeader(
    "set-cookie",
    `${COOKIE_NAME}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0`,
  );
}