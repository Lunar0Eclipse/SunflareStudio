import { readJson, writeJson } from "./storage";

export type StudioMember = {
  id: string;
  name: string;
  handle: string;
  role: string;
  skills: string[];
  load: number;
  availability: string;
  avatar: string;
  rank: string;
  portfolioUrl: string;
};

export const seedMembers: StudioMember[] = [
  {
    id: "mira",
    name: "Mira Chen",
    handle: "mira.fx",
    role: "Technical artist",
    skills: ["VFX", "Lighting", "Animation"],
    load: 72,
    availability: "Focused",
    avatar: "https://i.pravatar.cc/160?img=47",
    rank: "Lead creator",
    portfolioUrl: "https://discord.com",
  },
  {
    id: "ash",
    name: "Ash Carter",
    handle: "ash.builds",
    role: "Environment artist",
    skills: ["3D modeling", "World building", "Optimization"],
    load: 58,
    availability: "Available soon",
    avatar: "https://i.pravatar.cc/160?img=12",
    rank: "World builder",
    portfolioUrl: "https://discord.com",
  },
  {
    id: "kairo",
    name: "Kairo Vale",
    handle: "kairo.dev",
    role: "Systems engineer",
    skills: ["Luau", "Frameworks", "UI systems"],
    load: 84,
    availability: "Focused",
    avatar: "https://i.pravatar.cc/160?img=68",
    rank: "Systems lead",
    portfolioUrl: "https://discord.com",
  },
  {
    id: "nova",
    name: "Nova Reyes",
    handle: "nova.codes",
    role: "Gameplay engineer",
    skills: ["Combat", "Networking", "Tools"],
    load: 36,
    availability: "Available",
    avatar: "https://i.pravatar.cc/160?img=32",
    rank: "Gameplay builder",
    portfolioUrl: "https://discord.com",
  },
];

export async function readMembers() {
  const members = await readJson<Partial<StudioMember>[]>("team.json", seedMembers);
  return members.map((member, index) => ({
    ...seedMembers[index % seedMembers.length],
    ...member,
    skills: member.skills ?? [],
    avatar: member.avatar ?? "https://i.pravatar.cc/160?img=32",
    rank: member.rank ?? member.role ?? "Creator",
    portfolioUrl: member.portfolioUrl ?? "https://discord.com",
  })) as StudioMember[];
}

export async function writeMembers(members: StudioMember[]) {
  await writeJson("team.json", members);
}