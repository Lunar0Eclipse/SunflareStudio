import { type FormEvent, type ReactNode, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleDot,
  ExternalLink,
  Filter,
  Image as ImageIcon,
  LockKeyhole,
  LogIn,
  LogOut,
  Menu,
  Moon,
  Plus,
  RefreshCw,
  Search,
  Send,
  Settings2,
  Sparkles,
  Sun,
  Terminal,
  Users,
  X,
  Zap,
} from "lucide-react";
import {
  getGetDashboardMembersQueryKey,
  getGetDashboardSummaryQueryKey,
  getGetDashboardTasksQueryKey,
  getGetTeamRosterQueryKey,
  useCreateCommissionInquiry,
  useCreateDashboardTask,
  useCreateRecruitmentApplication,
  useGetAssets,
  useGetDashboardMembers,
  useGetDashboardSummary,
  useGetDashboardTasks,
  useGetGames,
  useGetInquiryAssistantResponse,
  useGetPortfolio,
  useGetSession,
  useGetStudioMembers,
  useGetStudioOverview,
  useGetTeamRoster,
  useHealthCheck,
  useLogout,
  useUpdateDashboardMembers,
  useUpdateDashboardTask,
} from "@workspace/api-client-react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Link, Route, Router as WouterRouter, Switch, useLocation } from "wouter";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { siteConfig } from "@/config/siteConfig";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();
const pageTransition = { duration: 0.45, ease: [0.2, 0.75, 0.2, 1] as const };

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="brand-mark" data-testid="link-logo">
      <span className="brand-logo-wrap">
        <img src={siteConfig.brand.logo} alt={siteConfig.brand.name} className="brand-logo" />
      </span>
      {!compact && <span className="brand-name">SUNFLARE<span>/</span>STUDIOS</span>}
    </Link>
  );
}

function ThemeToggle() {
  const [dark, setDark] = useState(() => localStorage.getItem("sunflare-theme") === "dark");
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("sunflare-theme", dark ? "dark" : "light");
  }, [dark]);
  return (
    <button type="button" className="icon-button" onClick={() => setDark((value) => !value)} aria-label="Toggle color theme" data-testid="button-toggle-theme">
      {dark ? <Sun size={16} /> : <Moon size={16} />}
    </button>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const overviewQuery = useGetStudioOverview();
  const invite = overviewQuery.data?.discordUrl || siteConfig.links.discordInvite;
  const nav = siteConfig.navigation;
  return (
    <div className="site-shell">
      <header className="site-header">
        <div className="header-inner">
          <Logo />
          <nav className="desktop-nav" aria-label="Main navigation">
            {nav.map((item) => (
              <Link key={item.href} href={item.href} className={location === item.href ? "nav-link active" : "nav-link"} data-testid={`link-nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}>
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="header-actions">
            <Link href="/team" className="login-link" data-testid="link-header-login"><LogIn size={14} /> {siteConfig.copy.login}</Link>
            <a href={invite} target="_blank" rel="noreferrer" className="discord-button" data-testid="link-header-discord"><span className="live-dot" />{siteConfig.copy.joinDiscord}</a>
            <ThemeToggle />
            <button type="button" className="icon-button menu-button" onClick={() => setOpen((value) => !value)} aria-label="Open navigation" data-testid="button-open-navigation">
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        <AnimatePresence>
          {open && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="mobile-menu">
              {nav.map((item) => <Link key={item.href} href={item.href} onClick={() => setOpen(false)} className="mobile-nav-link" data-testid={`link-mobile-${item.label.toLowerCase().replace(/\s/g, "-")}`}>{item.label}<ChevronRight size={16} /></Link>)}
              <Link href="/team" onClick={() => setOpen(false)} className="mobile-nav-link"><LogIn size={16} /> {siteConfig.copy.login}</Link>
              <a href={invite} target="_blank" rel="noreferrer" className="mobile-discord" data-testid="link-mobile-discord">{siteConfig.copy.joinDiscord}<ArrowUpRight size={16} /></a>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
      <main>{children}</main>
      <footer className="site-footer">
        <div className="footer-inner">
          <div><Logo /><p className="footer-copy">{siteConfig.copy.heroDescription}</p></div>
          <div className="footer-links">{nav.map((item) => <Link key={item.href} href={item.href}>{item.label}</Link>)}<Link href="/team">Team workspace</Link><a href={invite} target="_blank" rel="noreferrer">Discord</a></div>
          <p className="footer-code">SF / RBX / 2026</p>
        </div>
      </footer>
    </div>
  );
}

function Reveal({ children, delay = 0, className = "" }: { children: ReactNode; delay?: number; className?: string }) {
  return <motion.div className={className} initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.16 }} transition={{ ...pageTransition, delay }}>{children}</motion.div>;
}

function Eyebrow({ children }: { children: ReactNode }) {
  return <p className="eyebrow">{children}</p>;
}

function ArrowLink({ href, children, dark = false }: { href: string; children: ReactNode; dark?: boolean }) {
  return <Link href={href} className={dark ? "arrow-link dark-link" : "arrow-link"}>{children}<ArrowUpRight size={15} /></Link>;
}

function PageIntro({ eyebrow, title, detail }: { eyebrow: string; title: ReactNode; detail: string }) {
  return <section className="page-intro shell-grid"><div className="page-intro-inner"><Eyebrow>{eyebrow}</Eyebrow><motion.h1 initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={pageTransition}>{title}</motion.h1><p>{detail}</p></div></section>;
}

function Home() {
  const overviewQuery = useGetStudioOverview();
  const healthQuery = useHealthCheck();
  const workQuery = useGetPortfolio();
  const membersQuery = useGetStudioMembers();
  const overview = overviewQuery.data;
  const members = membersQuery.data?.length ? membersQuery.data : siteConfig.members;
  const work = workQuery.data || [];
  const disciplines = overview?.disciplines || siteConfig.capabilities.map((item) => item.title);
  if (overviewQuery.isLoading) return <LoadingState label="Booting Sunflare systems" />;
  if (overviewQuery.isError || !overview) return <ErrorState retry={() => overviewQuery.refetch()} />;
  return (
    <div>
      <section id="home" className="hero-section">
        <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
        <div className="hero-inner">
          <Reveal className="hero-copy">
            <div className="hero-kicker"><span className="pulse-line" /><Eyebrow>{siteConfig.copy.eyebrow}</Eyebrow></div>
            <h1>{siteConfig.copy.heroTitle.split(" ").map((word, index) => <span key={word} className={index > 1 ? "hero-red" : ""}>{word} </span>)}</h1>
            <p>{siteConfig.copy.heroDescription}</p>
            <div className="hero-buttons"><Link href="/commissions" className="primary-button">{siteConfig.copy.heroHire}<ArrowUpRight size={16} /></Link><Link href="/recruitment" className="secondary-button">{siteConfig.copy.heroJoin}<ArrowRight size={16} /></Link></div>
            <div className="scroll-note"><span className="scroll-wheel" />{siteConfig.copy.scrollHint}</div>
          </Reveal>
          <Reveal delay={0.14} className="hero-gallery">
            <div className="gallery-stack">
              {siteConfig.gallery.slice(0, 3).map((image, index) => <motion.figure key={image.id} className={`hero-gallery-card card-${index + 1}`} animate={{ y: [0, index % 2 ? -10 : 10, 0], rotate: [index ? 2 : -3, index ? 0 : 1, index ? 2 : -3] }} transition={{ duration: 7 + index, repeat: Infinity, ease: "easeInOut" }}><img src={image.image} alt={image.alt} /><figcaption><span>{image.label}</span><span>0{index + 1}</span></figcaption></motion.figure>)}
            </div>
            <div className="signal-card"><span>Studio signal</span><strong><CircleDot size={12} /> {healthQuery.data?.status || "online"}</strong></div>
          </Reveal>
        </div>
      </section>
      <section className="ticker-section"><div className="ticker-track">{[...disciplines, ...disciplines].map((item, index) => <span key={`${item}-${index}`}>{item}<i>✦</i></span>)}</div></section>
      <section className="home-section capabilities-section"><div className="section-lead"><Eyebrow>Capabilities / 01—04</Eyebrow><h2>Built for the moments players remember.</h2><p>{overview.description}</p><ArrowLink href="/work">View our work</ArrowLink></div><div className="capability-grid">{siteConfig.capabilities.map((item, index) => <Reveal key={item.number} delay={index * 0.06}><article className="capability-card"><span className="cap-number">{item.number}</span><Sparkles size={20} className="cap-icon" /><h3>{item.title}</h3><p>{item.text}</p></article></Reveal>)}</div></section>
      <section className="home-section home-gallery-section" id="gallery"><div className="section-heading"><div><Eyebrow>{siteConfig.copy.galleryEyebrow}</Eyebrow><h2>{siteConfig.copy.galleryTitle}</h2></div><ArrowLink href="/work">{siteConfig.copy.galleryButton}</ArrowLink></div><div className="image-marquee"><div className="marquee-track">{[...siteConfig.gallery, ...siteConfig.gallery].map((image, index) => <figure className="marquee-card" key={`${image.id}-${index}`}><img src={image.image} alt={image.alt} /><figcaption>{image.label}</figcaption></figure>)}</div></div></section>
      <section className="home-section work-preview" id="work"><div className="section-heading"><div><Eyebrow>Selected work / 03—06</Eyebrow><h2>Proof, not promises.</h2></div><ArrowLink href="/work">View all works</ArrowLink></div><div className="work-preview-grid">{work.slice(0, 3).map((item, index) => <Reveal key={item.id} delay={index * 0.06}><Link href="/work" className={`work-tile work-tile-${index}`}><img src={item.image} alt={item.title} /><div><span>{item.tag}</span><strong>{item.title}</strong></div></Link></Reveal>)}</div></section>
      <section className="home-section members-section" id="members"><div className="section-heading"><div><Eyebrow>{siteConfig.copy.membersEyebrow}</Eyebrow><h2>{siteConfig.copy.membersTitle}</h2></div><Link href="/team" className="secondary-button">{siteConfig.copy.membersButton}<Users size={15} /></Link></div><div className="member-grid">{members.map((member: any, index) => <Reveal key={member.id} delay={index * 0.06}><MemberCard member={member} /></Reveal>)}</div></section>
      <section className="cta-band" id="hire"><div><Eyebrow>Ready when you are</Eyebrow><h2>Bring the spark.<br /><span>We build the rest.</span></h2></div><Link href="/commissions" className="light-button">{siteConfig.copy.heroHire}<ArrowUpRight size={16} /></Link></section>
    </div>
  );
}

function MemberCard({ member }: { member: any }) {
  return <article className="member-card"><img src={member.avatar || member.pfp} alt={member.name} /><div className="member-info"><div><span className="member-rank">{member.rank || member.role}</span><h3>{member.name}</h3><p>{member.specialty || member.role}</p></div><a href={member.portfolioUrl || "#"} target="_blank" rel="noreferrer" className="member-link" aria-label={`View ${member.name}'s portfolio`}><ArrowUpRight size={16} /></a></div></article>;
}

function Marketplace() {
  const query = useGetAssets(); const [search, setSearch] = useState(""); const [category, setCategory] = useState("All"); const assets = query.data || []; const categories = ["All", ...Array.from(new Set(assets.map((asset) => asset.category)))]; const filtered = useMemo(() => assets.filter((asset) => `${asset.title} ${asset.description} ${asset.creator} ${asset.category}`.toLowerCase().includes(search.toLowerCase()) && (category === "All" || asset.category === category)), [assets, category, search]);
  return <><PageIntro eyebrow="Marketplace / ready-to-deploy" title={<>Good bones.<br /><span>Great games.</span></>} detail="Production-grade assets and systems from the Sunflare bench. Drop them into your next build, then make them your own." /><section className="content-section"><div className="catalog-controls"><label><Search size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search the catalog" data-testid="input-marketplace-search" /></label><div className="filter-row"><Filter size={15} />{categories.map((item) => <button type="button" key={item} onClick={() => setCategory(item)} className={category === item ? "filter-chip selected" : "filter-chip"}>{item}</button>)}</div></div>{query.isLoading ? <LoadingState label="Indexing assets" /> : query.isError ? <ErrorState retry={() => query.refetch()} /> : filtered.length === 0 ? <EmptyState title="No matching assets" detail="Try a wider search, or check back when the next drop hits." /> : <div className="catalog-grid">{filtered.map((asset) => <AssetCard key={asset.id} asset={asset} />)}</div>}</section></>;
}

function AssetCard({ asset }: { asset: any }) {
  return <article className="catalog-card"><div className="catalog-image"><img src={asset.image} alt={asset.title} /><span>{asset.category}</span></div><div className="catalog-content"><div><h3>{asset.title}</h3><p>{asset.description}</p></div><div className="seller-row"><span>{asset.creator} <small>@{asset.creatorHandle}</small></span><a href={siteConfig.links.contact} target="_blank" rel="noreferrer">Contact seller <ArrowUpRight size={12} /></a></div></div></article>;
}

function Games() {
  const query = useGetGames();
  return <><PageIntro eyebrow="Games / shipped into the wild" title={<>Play the<br /><span>finished worlds.</span></>} detail="A growing shelf of Roblox experiences made with stubborn attention to feel, flow, and the tiny details players notice." /><section className="content-section">{query.isLoading ? <LoadingState label="Loading published games" /> : query.isError ? <ErrorState retry={() => query.refetch()} /> : <div className="games-grid">{(query.data || []).map((game, index) => <article className={index === 0 ? "game-card featured" : "game-card"} key={game.id}><img src={game.image} alt={game.title} /><div className="game-overlay"><span>{game.status}</span><div><Eyebrow>{game.genre}</Eyebrow><h2>{game.title}</h2><p>{game.description}</p><a href={game.playUrl} target="_blank" rel="noreferrer">Play experience <ExternalLink size={14} /></a></div></div></article>)}</div>}</section></>;
}

function Work() {
  const query = useGetPortfolio();
  return <><PageIntro eyebrow="Work / selected systems" title={<>Behind every<br /><span>good feeling.</span></>} detail="A closer look at the frameworks, interfaces, and visual systems we have put through the paces." /><section className="content-section work-list">{query.isLoading ? <LoadingState label="Pulling case studies" /> : query.isError ? <ErrorState retry={() => query.refetch()} /> : (query.data || []).map((item, index) => <Reveal key={item.id}><article className="case-study"><div className="case-image"><img src={item.image} alt={item.title} /><span>{item.tag}</span></div><div><Eyebrow>Case / 0{index + 1}</Eyebrow><h2>{item.title}</h2><p>{item.summary}</p><ul>{item.details.map((detail) => <li key={detail}><Check size={15} />{detail}</li>)}</ul></div></article></Reveal>)}</section></>;
}

type IntakeKind = "commission" | "recruitment";
function GuidedIntake({ kind }: { kind: IntakeKind }) {
  const isCommission = kind === "commission";
  const steps = siteConfig.intake[kind];
  const assistant = useGetInquiryAssistantResponse();
  const commission = useCreateCommissionInquiry();
  const recruitment = useCreateRecruitmentApplication();
  const [step, setStep] = useState(0); const [answer, setAnswer] = useState(""); const [answers, setAnswers] = useState<Record<string, string>>({}); const [chat, setChat] = useState<{ role: "assistant" | "user"; text: string }[]>([{ role: "assistant", text: isCommission ? "Hey. Tell us what you are building and we will turn the spark into a clear first brief." : "Hey. Show us what you make and where you want to take it next." }]); const [receipt, setReceipt] = useState<{ id: string; summary: string; message: string } | null>(null); const [error, setError] = useState("");
  const current = steps[step]; const teamOptions = ["Solo", "Small team · 1–10", "Big team · 10–100", "Organization · 1–1000", "Enterprise · talk to us"];
  const reset = () => { setStep(0); setAnswer(""); setAnswers({}); setReceipt(null); setError(""); setChat([{ role: "assistant", text: isCommission ? "Hey. Tell us what you are building and we will turn the spark into a clear first brief." : "Hey. Show us what you make and where you want to take it next." }]); };
  const submitFinal = (finalAnswers: Record<string, string>, aiSummary: string) => {
    const id = `SF-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    const summary = aiSummary || Object.entries(finalAnswers).map(([key, value]) => `${key}: ${value}`).join(" · ");
    if (isCommission) {
      commission.mutate({ data: { name: finalAnswers.name, details: finalAnswers.project, teamSize: finalAnswers.teamSize, summary, orderId: id, projectType: "Roblox game development" } }, { onSuccess: (result) => setReceipt({ id: result.id || id, summary, message: result.message }), onError: () => setError("The brief could not be sent. Your answers are still here — try again.") });
    } else {
      recruitment.mutate({ data: { name: finalAnswers.name, role: finalAnswers.role, skills: [finalAnswers.role], portfolio: finalAnswers.portfolio, about: summary } }, { onSuccess: (result) => setReceipt({ id: result.id || id, summary, message: result.message }), onError: () => setError("The application could not be sent. Your answers are still here — try again.") });
    }
  };
  const sendAnswer = (event: FormEvent) => { event.preventDefault(); if (!answer.trim()) return; const nextAnswers = { ...answers, [current.key]: answer.trim() }; setAnswers(nextAnswers); setChat((old) => [...old, { role: "user", text: answer.trim() }]); setAnswer(""); setError(""); assistant.mutate({ data: { kind, step: current.key, answer: answer.trim(), answers: nextAnswers } }, { onSuccess: (result) => { setChat((old) => [...old, { role: "assistant", text: result.reply }]); if (step === steps.length - 1) submitFinal(nextAnswers, result.summary); else { setStep((value) => value + 1); setChat((old) => [...old, { role: "assistant", text: result.nextQuestion }]); } }, onError: () => setError("The assistant is taking a beat. Please try this answer again.") }); };
  if (receipt) {
    const discordMessage = `SUNFLARE STUDIOS ORDER ${receipt.id}\nName: ${answers.name}\n${isCommission ? `Project: ${answers.project}\nTeam size: ${answers.teamSize}` : `Speciality: ${answers.role}\nPortfolio: ${answers.portfolio}`}\nAI SUMMARY: ${receipt.summary}`;
    return <div className="receipt-card"><span className="receipt-check"><Check size={24} /></span><Eyebrow>{isCommission ? "Order ready" : "Application received"}</Eyebrow><h2>{receipt.message}</h2><div className="order-id"><span>Order ID</span><strong>{receipt.id}</strong></div><div className="summary-box"><span>AI summary</span><p>{receipt.summary}</p></div><div className="receipt-actions"><a href={`${siteConfig.links.orderDiscord}?message=${encodeURIComponent(discordMessage)}`} target="_blank" rel="noreferrer" className="primary-button">{siteConfig.copy.order}<ArrowUpRight size={16} /></a><button type="button" className="secondary-button" onClick={() => void navigator.clipboard?.writeText(discordMessage)}>{siteConfig.copy.copyMessage}<CheckCircle2 size={15} /></button></div><button type="button" className="text-button" onClick={reset}>Start another brief <RefreshCw size={14} /></button></div>;
  }
  const pending = assistant.isPending || commission.isPending || recruitment.isPending;
  return <div className="intake-card"><div className="intake-progress"><div><span>Step {step + 1} of {steps.length}</span><strong>{Math.round(((step + 1) / steps.length) * 100)}%</strong></div><div className="progress-line"><span style={{ width: `${((step + 1) / steps.length) * 100}%` }} /></div></div><div className="chat-log">{chat.slice(-4).map((item, index) => <motion.div key={`${item.role}-${index}-${item.text}`} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={item.role === "assistant" ? "chat-bubble assistant-bubble" : "chat-bubble user-bubble"}>{item.text}</motion.div>)}</div><form onSubmit={sendAnswer} className="question-form"><label><span>{current.label}</span>{current.key === "teamSize" ? <div className="choice-grid">{teamOptions.map((option) => <button type="button" key={option} className={answer === option ? "choice selected" : "choice"} onClick={() => setAnswer(option)}>{option}<ChevronRight size={15} /></button>)}</div> : <input autoFocus value={answer} onChange={(event) => setAnswer(event.target.value)} placeholder={current.placeholder} />}</label>{error && <p className="form-error">{error}</p>}<button type="submit" disabled={pending || !answer.trim()} className="primary-button">{pending ? "THINKING…" : step === steps.length - 1 ? (isCommission ? "Create order" : "Send application") : "Continue"}<ArrowRight size={15} /></button></form></div>;
}

function Commission() {
  return <><PageIntro eyebrow="Hire Us / guided brief" title={<>Bring the spark.<br /><span>We build the rest.</span></>} detail="One question at a time. No email wall. We will turn your answers into a clean brief you can place directly in Discord." /><section className="intake-section"><div className="intake-aside"><Eyebrow>Commission intake</Eyebrow><h2>A sharper first conversation starts here.</h2><p>The assistant keeps it quick, asks only what matters, and creates a handoff message with your order ID.</p><div className="intake-points"><span><CheckCircle2 size={17} />No email required</span><span><CheckCircle2 size={17} />AI-written project summary</span><span><CheckCircle2 size={17} />Ready-to-paste Discord handoff</span></div></div><GuidedIntake kind="commission" /></section></>;
}

function Recruitment() {
  return <><PageIntro eyebrow="Join Us / open channel" title={<>Make the weird<br /><span>stuff work.</span></>} detail="Tell us what you make, where we can see it, and what kind of problems you want to solve with the crew." /><section className="intake-section"><div className="intake-aside"><Eyebrow>Recruitment intake</Eyebrow><h2>Show us the work, not a perfect resume.</h2><p>We care about taste, follow-through, and the last 10%. The assistant will shape your answers into a useful introduction.</p><div className="intake-points"><span><CheckCircle2 size={17} />No email required</span><span><CheckCircle2 size={17} />One question at a time</span><span><CheckCircle2 size={17} />Portfolio-first review</span></div></div><GuidedIntake kind="recruitment" /></section></>;
}

function Team() {
  const sessionQuery = useGetSession(); const session = sessionQuery.data; const authenticated = Boolean(session?.authenticated); const isAdmin = Boolean(session?.isAdmin); const logout = useLogout(); const summaryQuery = useGetDashboardSummary({ query: { enabled: authenticated, queryKey: getGetDashboardSummaryQueryKey() } }); const tasksQuery = useGetDashboardTasks({ query: { enabled: authenticated, queryKey: getGetDashboardTasksQueryKey() } }); const rosterQuery = useGetTeamRoster({ query: { enabled: authenticated, queryKey: getGetTeamRosterQueryKey() } }); const membersQuery = useGetDashboardMembers({ query: { enabled: isAdmin, queryKey: getGetDashboardMembersQueryKey() } }); const createTask = useCreateDashboardTask(); const updateTask = useUpdateDashboardTask(); const updateMembers = useUpdateDashboardMembers(); const [taskOpen, setTaskOpen] = useState(false); const [devOpen, setDevOpen] = useState(false); const [task, setTask] = useState({ title: "", project: "", assignee: "", status: "todo", priority: "normal", details: "" }); const [members, setMembers] = useState<any[]>([]);
  useEffect(() => { if (membersQuery.data) setMembers(membersQuery.data); }, [membersQuery.data]);
  if (sessionQuery.isLoading) return <LoadingState label="Checking team credentials" />;
  if (!authenticated) return <section className="auth-screen shell-grid"><div><span className="auth-icon"><LockKeyhole size={25} /></span><Eyebrow>Internal / restricted</Eyebrow><h1>The workbench is for the crew.</h1><p>Sign in with Discord to see live projects, tasks, and the people making the magic happen.</p><a href="/api/auth/discord" className="primary-button" data-testid="button-discord-signin">SIGN IN WITH DISCORD<ArrowUpRight size={15} /></a></div></section>;
  const addTask = (event: FormEvent) => { event.preventDefault(); createTask.mutate({ data: task }, { onSuccess: () => { setTaskOpen(false); setTask({ title: "", project: "", assignee: "", status: "todo", priority: "normal", details: "" }); void tasksQuery.refetch(); } }); };
  const saveMembers = () => updateMembers.mutate({ data: members }, { onSuccess: () => { void membersQuery.refetch(); void rosterQuery.refetch(); } });
  return <section className="team-section"><div className="team-header"><div><Eyebrow>Team OS / live workspace</Eyebrow><h1>Good morning, {session?.username || "builder"}.</h1><p>The studio is moving. Here is the signal.</p></div><div className="team-actions">{isAdmin && <button type="button" className={devOpen ? "secondary-button selected" : "secondary-button"} onClick={() => setDevOpen((value) => !value)}><Settings2 size={14} /> Dev</button>}<button type="button" className="icon-button" onClick={() => { void summaryQuery.refetch(); void tasksQuery.refetch(); void rosterQuery.refetch(); }} aria-label="Refresh workspace"><RefreshCw size={15} /></button><button type="button" className="secondary-button" onClick={() => logout.mutate(undefined, { onSuccess: () => void sessionQuery.refetch() })}><LogOut size={14} /> Log out</button></div></div>{isAdmin && devOpen && <DevPanel members={members} setMembers={setMembers} save={saveMembers} pending={updateMembers.isPending} />}{!devOpen && <><div className="stat-grid">{[["Active projects", summaryQuery.data?.activeProjects ?? "—"], ["Completed this month", summaryQuery.data?.completedThisMonth ?? "—"], ["Open tasks", summaryQuery.data?.openTasks ?? "—"], ["Team members", summaryQuery.data?.teamMembers ?? "—"]].map(([label, value]) => <div className="stat-card" key={label}><Zap size={17} /><strong>{value}</strong><span>{label}</span></div>)}</div><div className="team-grid"><div className="task-board"><div className="board-heading"><div><Eyebrow>Queue / attention</Eyebrow><h2>Task board</h2></div><button type="button" className="primary-button small" onClick={() => setTaskOpen((value) => !value)}><Plus size={14} /> New task</button></div>{taskOpen && <form onSubmit={addTask} className="task-form"><input required placeholder="Task title" value={task.title} onChange={(event) => setTask((old) => ({ ...old, title: event.target.value }))} /><input required placeholder="Project" value={task.project} onChange={(event) => setTask((old) => ({ ...old, project: event.target.value }))} /><input required placeholder="Assignee" value={task.assignee} onChange={(event) => setTask((old) => ({ ...old, assignee: event.target.value }))} /><select value={task.priority} onChange={(event) => setTask((old) => ({ ...old, priority: event.target.value }))}><option>normal</option><option>high</option><option>urgent</option></select><textarea required placeholder="Details" value={task.details} onChange={(event) => setTask((old) => ({ ...old, details: event.target.value }))} /><button type="submit" className="secondary-button">Create task</button></form>}{(tasksQuery.data || []).map((item) => <TaskRow key={item.id} task={item} onStatus={(status) => updateTask.mutate({ id: item.id, data: { status } }, { onSuccess: () => void tasksQuery.refetch() })} />)}</div><div className="crew-board"><div className="board-heading"><div><Eyebrow>Roster / current load</Eyebrow><h2>The crew</h2></div><Users size={18} /></div>{(rosterQuery.data || []).map((member) => <MemberRow member={member} key={member.id} />)}</div></div></>}</section>;
}

function DevPanel({ members, setMembers, save, pending }: { members: any[]; setMembers: (members: any[]) => void; save: () => void; pending: boolean }) {
  const update = (index: number, key: string, value: string) => setMembers(members.map((member, memberIndex) => memberIndex === index ? { ...member, [key]: value } : member));
  return <div className="dev-panel"><div className="board-heading"><div><Eyebrow>Admin only / content controls</Eyebrow><h2>Edit member list</h2></div><button type="button" className="primary-button small" onClick={save} disabled={pending}>{pending ? "Saving…" : "Save roster"}<Check size={14} /></button></div><p className="dev-note">Changes here update the public member cards and team roster. Add your own PFP, rank, speciality, and portfolio link.</p>{members.map((member, index) => <div className="dev-member" key={member.id}><input aria-label={`${member.name} name`} value={member.name} onChange={(event) => update(index, "name", event.target.value)} /><input aria-label={`${member.name} role`} value={member.role} onChange={(event) => update(index, "role", event.target.value)} /><input aria-label={`${member.name} rank`} value={member.rank} onChange={(event) => update(index, "rank", event.target.value)} /><input aria-label={`${member.name} avatar`} value={member.avatar} onChange={(event) => update(index, "avatar", event.target.value)} /><input aria-label={`${member.name} portfolio`} value={member.portfolioUrl} onChange={(event) => update(index, "portfolioUrl", event.target.value)} /></div>)}</div>;
}

function TaskRow({ task, onStatus }: { task: any; onStatus: (status: string) => void }) {
  const [open, setOpen] = useState(false); const next = task.status === "done" ? "todo" : task.status === "in_progress" ? "done" : "in_progress";
  return <div className="task-row"><button type="button" className={task.status === "done" ? "task-check done" : "task-check"} onClick={() => onStatus(next)} aria-label={`Move ${task.title} to ${next}`}>{task.status === "done" && <Check size={12} />}</button><div className="task-main"><div className="task-title"><strong>{task.title}</strong><span>{task.priority}</span><em>{task.status.replace("_", " ")}</em></div><p>{task.project} · {task.assignee}</p>{open && <small>{task.details}</small>}</div><button type="button" className="row-chevron" onClick={() => setOpen((value) => !value)} aria-label="Toggle task details">{open ? <ChevronDown size={17} /> : <ChevronRight size={17} />}</button></div>;
}

function MemberRow({ member }: { member: any }) {
  const load = Math.max(0, Math.min(100, Number(member.load) || 0));
  return <div className="roster-row"><img src={member.avatar} alt={member.name} /><div><div className="roster-name"><strong>{member.name}</strong><span>{load}%</span></div><p>{member.role} · {member.availability}</p><div className="load-bar"><span style={{ width: `${load}%` }} /></div></div></div>;
}

function LoadingState({ label }: { label: string }) { return <div className="loading-state"><div className="loading-orb" /><p>{label}</p></div>; }
function ErrorState({ retry }: { retry: () => void }) { return <div className="empty-state"><Zap size={24} /><h2>The studio feed went quiet.</h2><p>Give it another shot. No progress was lost.</p><button type="button" className="secondary-button" onClick={retry}><RefreshCw size={14} /> Try again</button></div>; }
function EmptyState({ title, detail }: { title: string; detail: string }) { return <div className="empty-state"><ImageIcon size={24} /><h2>{title}</h2><p>{detail}</p></div>; }

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Shell><Switch><Route path="/" component={Home} /><Route path="/commissions" component={Commission} /><Route path="/marketplace" component={Marketplace} /><Route path="/games" component={Games} /><Route path="/work" component={Work} /><Route path="/recruitment" component={Recruitment} /><Route path="/team" component={Team} /><Route component={NotFound} /></Switch></Shell></ErrorBoundary>;
}

function App() { return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>; }
export default App;