/**
 * Sunflare Studios — editable site content
 * =========================================
 *
 * This is the main place to customize the public website without changing
 * layout or application logic. The comments are intentionally detailed:
 *
 * - Change brand colors, fonts, button labels, and navigation here.
 * - Replace any image URL in `media`, `gallery`, `work`, `games`, or `members`.
 * - Replace any copy in `copy` and the page-specific arrays below.
 * - Replace Discord, Roblox, portfolio, and seller links in one place.
 * - Keep the object shapes intact so the TypeScript build can catch typos.
 *
 * Local images:
 * 1. Put an image in `attached_assets/`.
 * 2. Add an import at the top of this file.
 * 3. Use that imported value for a logo or gallery image.
 *
 * Remote images:
 * - Use a complete https:// URL.
 * - Prefer a stable CDN or your own hosted asset.
 * - The site will still render a designed fallback if an image fails.
 */

import logoImage from "@assets/Sunflare_1788181239886.png";
import compassImage from "@assets/IMG_0104_1788181196117.png";
import palmsImage from "@assets/imgage_1788181221314.png";
import galleryFrame from "@assets/image_1788182243464.png";

export const siteConfig = {
  brand: {
    name: "Sunflare Studios",
    shortName: "Sunflare",
    logo: logoImage,
    colors: {
      /** Main logo red. */
      red: "#dd0000",
      /** Flame / hover accent. */
      orange: "#ff6200",
      /** Light mode canvas background from the logo. */
      lightBackground: "#fff7e3",
      /** Supporting ink and dark-mode values. */
      ink: "#241511",
      darkBackground: "#140d0b",
    },
    fonts: {
      /**
       * The logo lettering is Tropika on Canva. This is used for the
       * wordmark image, while the editable display font below is used for
       * headings. Replace these Google font names or self-hosted CSS values
       * if you want a different text pairing.
       */
      logo: "Tropika",
      display: "Space Grotesk",
      body: "DM Sans",
      mono: "DM Mono",
    },
  },

  links: {
    /** Replace with the studio's real Discord invite. */
    discordInvite: "https://discord.gg/sunflare",
    /** Destination for the generated Place Order button. */
    orderDiscord: "https://discord.com/channels/@me",
    /** Optional direct URL for the studio contact button. */
    contact: "https://discord.gg/sunflare",
  },

  navigation: [
    { href: "/", label: "Studio", scrollId: "home" },
    { href: "/work", label: "Work", scrollId: "work" },
    { href: "/games", label: "Games", scrollId: "games" },
    { href: "/marketplace", label: "Marketplace", scrollId: "marketplace" },
    { href: "/commissions", label: "Hire Us", scrollId: "hire" },
    { href: "/recruitment", label: "Join Us", scrollId: "join" },
  ],

  copy: {
    eyebrow: "ROBLOX GAME DEVELOPMENT TEAM",
    heroTitle: "Worlds with a pulse.",
    heroDescription:
      "We build the systems, spaces, and spectacle behind unforgettable Roblox worlds.",
    heroHire: "Hire Us",
    heroJoin: "Join Us",
    scrollHint: "Keep scrolling to explore the studio",
    galleryEyebrow: "The work / in motion",
    galleryTitle: "A little proof goes a long way.",
    galleryDescription:
      "Systems, environments, VFX, and interfaces made to feel good under a player's hands.",
    galleryButton: "View all works",
    membersEyebrow: "The crew / currently online",
    membersTitle: "Meet the people behind the feeling.",
    membersButton: "View individual members",
    login: "Log In",
    joinDiscord: "Join the Discord",
    order: "Place Order",
    copyMessage: "Copy Discord message",
    footer: "A small Roblox team making loud, tactile worlds for players who notice the details.",
    statusLabel: "Studio signal",
    statusOnline: "online / building",
    viewWork: "View the work",
    viewGames: "View games",
  },
  pages: {
    work: { eyebrow: "Work / selected systems", title: "Behind every good feeling.", detail: "Frameworks, interfaces, and visual systems put through the paces before they reach a player." },
    games: { eyebrow: "Games / shipped into the wild", title: "Play the finished worlds.", detail: "A growing shelf of Roblox experiences made with stubborn attention to feel, flow, and the tiny details players notice." },
    marketplace: { eyebrow: "Marketplace / ready to deploy", title: "Good bones. Great games.", detail: "Production-grade assets and systems from the Sunflare bench. Drop them into your next build, then make them your own." },
    commissions: { eyebrow: "Commissions / start a build", title: "Bring the spark. We build the rest.", detail: "Tell us what is in your head. We will come back with a sharp read on scope, shape, and the people who should make it." },
    recruitment: { eyebrow: "Recruitment / open roles", title: "Make the weird stuff work.", detail: "We are looking for builders who care about the last 10%. If you have a point of view and a body of work, we want to see it." },
  },

  /**
   * Landing page motion gallery. Change each image, caption, and alt text
   * without touching the gallery component.
   */
  gallery: [
    {
      id: "strawberries",
      image: palmsImage,
      label: "World building",
      alt: "Atmospheric game environment",
    },
    {
      id: "deep-diving",
      image: compassImage,
      label: "Lighting studies",
      alt: "Blue and purple abstract lighting",
    },
    {
      id: "train-track",
      image: galleryFrame,
      label: "Combat systems",
      alt: "Player-focused game scene",
    },
    {
      id: "santorini",
      image: palmsImage,
      label: "Environment art",
      alt: "Warm architectural environment",
    },
    {
      id: "blurry-lights",
      image: compassImage,
      label: "VFX direction",
      alt: "Neon lights at night",
    },
  ],

  capabilities: [
    { number: "01", title: "Game frameworks", text: "Reliable systems with responsive feedback and room to grow." },
    { number: "02", title: "3D modeling", text: "Props, environments, and characters with a point of view." },
    { number: "03", title: "VFX & lighting", text: "Readable spectacle that makes every ability land." },
    { number: "04", title: "Custom UI", text: "Interfaces that feel native to the universe around them." },
  ],

  /**
   * Public member cards are kept here as the instant-edit fallback. The live
   * API roster overrides these values when it is available, and admins can
   * update the live roster from the private Dev tab.
   */
  members: [
    {
      id: "mira",
      name: "Mira Chen",
      specialty: "Technical artist",
      rank: "Lead creator",
       pfp: "",
      portfolioUrl: "https://discord.com",
    },
    {
      id: "ash",
      name: "Ash Carter",
      specialty: "Environment artist",
      rank: "World builder",
       pfp: "",
      portfolioUrl: "https://discord.com",
    },
    {
      id: "kairo",
      name: "Kairo Vale",
      specialty: "Systems engineer",
      rank: "Systems lead",
       pfp: "",
      portfolioUrl: "https://discord.com",
    },
    {
      id: "nova",
      name: "Nova Reyes",
      specialty: "Gameplay engineer",
      rank: "Gameplay builder",
       pfp: "",
      portfolioUrl: "https://discord.com",
    },
  ],

  /**
   * These are the questions shown by the guided forms. The AI writes the
   * friendly response after each answer; these values control the fallback
   * question order and can be edited for a different intake experience.
   */
  intake: {
    commission: [
      { key: "name", label: "What should we call you?", placeholder: "Your name" },
      { key: "project", label: "What are you making?", placeholder: "Tell us about the project" },
      { key: "teamSize", label: "Who is behind the build?", placeholder: "Choose a team size" },
    ],
    recruitment: [
      { key: "name", label: "What should we call you?", placeholder: "Your name" },
      { key: "role", label: "What do you make best?", placeholder: "Your speciality" },
      { key: "portfolio", label: "Where can we see your work?", placeholder: "Portfolio link or username" },
    ],
    teamOptions: ["Solo", "Small team 1–10", "Big team 10–100", "Organization 1–1000", "Enterprise / talk to us"],
  },
} as const;

export type SiteConfig = typeof siteConfig;