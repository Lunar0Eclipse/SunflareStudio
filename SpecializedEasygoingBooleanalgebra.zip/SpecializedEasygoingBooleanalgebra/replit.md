# Sunflare Studios

Sunflare Studios is a Roblox game development team website with public studio content, Discord-powered intake forms, and a protected team workspace.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/sunflare-studios run dev` — run the public website
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required secrets: `DISCORD_WEBHOOK_URL`, `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`
- Optional env: `DISCORD_TEAM_IDS` — comma-separated Discord user IDs allowed into `/team`
- Optional env: `SUNFLARE_DATA_DIR` — override the file-backed storage directory

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/sunflare-studios/src/App.tsx` — public routes, theme switcher, forms, marketplace, and team UI
- `artifacts/sunflare-studios/src/index.css` — Sunflare light/dark red and ember theme
- `artifacts/api-server/src/routes/` — public content, inquiries, Discord OAuth, and dashboard routes
- `artifacts/api-server/src/lib/discord.ts` — structured Discord webhook delivery
- `artifacts/api-server/src/lib/storage.ts` and `artifacts/api-server/data/` — file-backed app data and submissions
- `lib/api-spec/openapi.yaml` — API contract source of truth

## Architecture decisions

- Public content is served through the shared API so marketplace, games, and portfolio entries can be replaced without rebuilding the frontend.
- Inquiry submissions are written to disk before their Discord notification is attempted, preserving the payload if Discord is temporarily unavailable.
- Team sessions use signed HttpOnly cookies and an explicit `DISCORD_TEAM_IDS` allowlist; there is no local password authentication.

## Product

Public visitors can explore Sunflare’s Roblox capabilities, work, games, marketplace assets, and recruitment openings. Clients can submit commission briefs, applicants can submit portfolios, and team members can use the Discord-protected workspace to track tasks and current load.

## User preferences

- Keep the studio centered on Roblox game development, Discord communication, and a high-energy red / ember visual identity.

## Gotchas

- Add real Discord user IDs to `DISCORD_TEAM_IDS` before using the team dashboard outside local preview.
- Replace the sample studio invite and marketplace creator identifiers in `artifacts/api-server/src/routes/studio.ts` with production values.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
