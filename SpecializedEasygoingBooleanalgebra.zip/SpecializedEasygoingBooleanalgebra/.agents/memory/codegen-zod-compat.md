---
name: OpenAPI numeric compatibility
description: A generator/runtime compatibility note for numeric fields in this workspace.
---

Use OpenAPI `number` for generated numeric fields when the workspace is on Zod 3; the current Orval output uses `zod.int()`, which Zod 3 does not expose.

**Why:** Code generation completed successfully, but the chained library typecheck failed when OpenAPI `integer` became `zod.int()` against the installed Zod 3 runtime.

**How to apply:** When adding API numeric fields, prefer `number` unless the workspace upgrades its Zod dependency and generated output is confirmed compatible.